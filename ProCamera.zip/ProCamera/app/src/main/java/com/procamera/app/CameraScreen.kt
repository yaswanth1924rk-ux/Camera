package com.procamera.app

import android.widget.Toast
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

private enum class CaptureMode { PHOTO, HDR, VIDEO, MANUAL }

@Composable
fun CameraScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val controller = remember { CameraController(context, lifecycleOwner) }

    var mode by remember { mutableStateOf(CaptureMode.PHOTO) }
    var isRecording by remember { mutableStateOf(false) }
    var manualIsoSlider by remember { mutableStateOf(400f) }
    var manualShutterSlider by remember { mutableStateOf(1f / 60f) }
    var capabilities by remember { mutableStateOf<SensorCapabilities?>(null) }

    Box(modifier = Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PreviewView(ctx).also { previewView ->
                    controller.bindToLifecycle(previewView) { cam ->
                        capabilities = controller.getSensorCapabilities()
                    }
                }
            }
        )

        // Top bar: mode selector
        Row(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 32.dp)
                .background(Color.Black.copy(alpha = 0.4f))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            CaptureMode.values().forEach { m ->
                Text(
                    text = m.name,
                    color = if (mode == m) Color.Yellow else Color.White,
                    modifier = Modifier.clickable { mode = m }
                )
            }
        }

        // Manual controls panel
        if (mode == CaptureMode.MANUAL) {
            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 16.dp)
                    .background(Color.Black.copy(alpha = 0.4f))
                    .padding(12.dp)
                    .width(200.dp)
            ) {
                val caps = capabilities
                Text("ISO: ${manualIsoSlider.toInt()}", color = Color.White)
                Slider(
                    value = manualIsoSlider,
                    onValueChange = {
                        manualIsoSlider = it
                        controller.manualIso = it.toInt()
                    },
                    valueRange = (caps?.isoMin?.toFloat() ?: 50f)..(caps?.isoMax?.toFloat() ?: 3200f)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text("Shutter: 1/${(1f / manualShutterSlider).toInt()}s", color = Color.White)
                Slider(
                    value = manualShutterSlider,
                    onValueChange = {
                        manualShutterSlider = it
                        controller.manualExposureNs = (it * 1_000_000_000L).toLong()
                    },
                    valueRange = (1f / 4000f)..(1f / 8f)
                )
            }
        }

        // Bottom shutter control
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 48.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            ShutterButton(
                isRecording = isRecording,
                onClick = {
                    when (mode) {
                        CaptureMode.PHOTO, CaptureMode.MANUAL -> {
                            controller.capturePhoto(
                                onSaved = { Toast.makeText(context, "Saved $it", Toast.LENGTH_SHORT).show() },
                                onError = { Toast.makeText(context, "Capture failed: ${it.message}", Toast.LENGTH_SHORT).show() }
                            )
                        }
                        CaptureMode.HDR -> {
                            Toast.makeText(context, "Capturing HDR bracket...", Toast.LENGTH_SHORT).show()
                            controller.captureHdrBracket(
                                onSaved = { Toast.makeText(context, "HDR saved $it", Toast.LENGTH_SHORT).show() },
                                onError = { Toast.makeText(context, "HDR failed: ${it.message}", Toast.LENGTH_SHORT).show() }
                            )
                        }
                        CaptureMode.VIDEO -> {
                            if (!isRecording) {
                                controller.startVideoRecording { name ->
                                    Toast.makeText(context, "Video saved $name", Toast.LENGTH_SHORT).show()
                                }
                                isRecording = true
                            } else {
                                controller.stopVideoRecording()
                                isRecording = false
                            }
                        }
                    }
                }
            )
        }
    }
}

@Composable
private fun ShutterButton(isRecording: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(80.dp)
            .clip(CircleShape)
            .background(if (isRecording) Color.Red else Color.White)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = if (isRecording) Icons.Filled.FiberManualRecord else Icons.Filled.Circle,
            contentDescription = "Shutter",
            tint = if (isRecording) Color.White else Color.Black,
            modifier = Modifier.size(36.dp)
        )
    }
}

