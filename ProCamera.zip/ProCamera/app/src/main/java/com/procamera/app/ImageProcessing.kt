package com.procamera.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.os.Build
import android.provider.MediaStore
import androidx.camera.core.ImageProxy
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.min

/**
 * Lightweight, dependency-free image processing used to squeeze extra quality out of the
 * phone's sensor: exposure fusion for HDR, and an unsharp-mask pass to recover perceived
 * detail that gets softened by the sensor's noise reduction.
 */
object ImageProcessing {

    /** Converts a captured frame (JPEG-backed ImageProxy) into a Bitmap. */
    fun imageProxyToBitmap(image: ImageProxy): Bitmap {
        val buffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        var bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        if (image.imageInfo.rotationDegrees != 0) {
            val matrix = Matrix().apply { postRotate(image.imageInfo.rotationDegrees.toFloat()) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, matrix, true)
        }
        return bmp
    }

    /**
     * Simplified exposure fusion (Mertens-style weighting without the Laplacian pyramid):
     * for each pixel, blends the best-exposed sample across the bracket based on how close
     * it is to mid-gray, favoring good contrast and saturation over blown highlights or
     * crushed shadows.
     */
    fun fuseExposures(frames: List<Bitmap>): Bitmap {
        if (frames.isEmpty()) throw IllegalArgumentException("No frames to fuse")
        if (frames.size == 1) return frames[0]

        val width = frames.minOf { it.width }
        val height = frames.minOf { it.height }
        val result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

        val pixelBuffers = frames.map { bmp ->
            val scaled = if (bmp.width != width || bmp.height != height)
                Bitmap.createScaledBitmap(bmp, width, height, true) else bmp
            val pixels = IntArray(width * height)
            scaled.getPixels(pixels, 0, width, 0, 0, width, height)
            pixels
        }

        val outPixels = IntArray(width * height)
        for (i in outPixels.indices) {
            var rSum = 0.0; var gSum = 0.0; var bSum = 0.0; var wSum = 0.0
            for (frame in pixelBuffers) {
                val p = frame[i]
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF
                val luminance = 0.299 * r + 0.587 * g + 0.114 * b
                // Weight peaks at mid-gray (well-exposed), falls off toward 0/255.
                val distanceFromMid = kotlin.math.abs(luminance - 128.0) / 128.0
                val weight = max(0.02, 1.0 - distanceFromMid * distanceFromMid)
                rSum += r * weight; gSum += g * weight; bSum += b * weight
                wSum += weight
            }
            val r = (rSum / wSum).toInt().coerceIn(0, 255)
            val g = (gSum / wSum).toInt().coerceIn(0, 255)
            val b = (bSum / wSum).toInt().coerceIn(0, 255)
            outPixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }
        result.setPixels(outPixels, 0, width, 0, 0, width, height)
        return result
    }

    /**
     * 3x3 unsharp mask: result = original + amount * (original - blurred).
     * Recovers edge detail that the sensor's built-in noise reduction tends to soften,
     * without the halo artifacts of an aggressive global sharpen.
     */
    fun unsharpMask(src: Bitmap, amount: Float = 0.6f): Bitmap {
        val w = src.width
        val h = src.height
        val pixels = IntArray(w * h)
        src.getPixels(pixels, 0, w, 0, 0, w, h)
        val out = pixels.copyOf()

        fun idx(x: Int, y: Int) = y * w + x

        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                var rBlur = 0; var gBlur = 0; var bBlur = 0
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        val p = pixels[idx(x + dx, y + dy)]
                        rBlur += (p shr 16) and 0xFF
                        gBlur += (p shr 8) and 0xFF
                        bBlur += p and 0xFF
                    }
                }
                rBlur /= 9; gBlur /= 9; bBlur /= 9

                val orig = pixels[idx(x, y)]
                val r = (orig shr 16) and 0xFF
                val g = (orig shr 8) and 0xFF
                val b = orig and 0xFF

                val newR = (r + amount * (r - rBlur)).toInt().coerceIn(0, 255)
                val newG = (g + amount * (g - gBlur)).toInt().coerceIn(0, 255)
                val newB = (b + amount * (b - bBlur)).toInt().coerceIn(0, 255)

                out[idx(x, y)] = (0xFF shl 24) or (newR shl 16) or (newG shl 8) or newB
            }
        }
        val result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        result.setPixels(out, 0, w, 0, 0, w, h)
        return result
    }

    fun saveBitmap(context: Context, bmp: Bitmap, name: String) {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT > Build.VERSION_CODES.P) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ProCamera")
            }
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return
        resolver.openOutputStream(uri)?.use { out ->
            bmp.compress(Bitmap.CompressFormat.JPEG, 100, out)
        }
    }
}
