package com.procamera.app

import android.content.ContentValues
import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.video.VideoCapture
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.Executor
import java.util.concurrent.Executors

/**
 * Wraps CameraX use cases and exposes:
 *  - Standard high quality photo capture (max JPEG quality, CameraX zero-shutter-lag disabled
 *    in favor of MAXIMIZE_QUALITY capture mode).
 *  - HDR bracket capture: 3 exposures (under / normal / over) fused into one image.
 *  - Highest-resolution video recording with stabilization when the sensor supports it.
 *  - Manual ISO / shutter speed / focus distance via Camera2Interop.
 */
class CameraController(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner
) {
    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null

    private lateinit var preview: Preview
    private lateinit var imageCapture: ImageCapture
    private lateinit var videoCapture: VideoCapture<Recorder>
    private var activeRecording: Recording? = null

    private val cameraExecutor: Executor = Executors.newSingleThreadExecutor()

    // Manual control state (null = auto)
    var manualIso: Int? = null
    var manualExposureNs: Long? = null
    var manualFocusDistance: Float? = null

    fun bindToLifecycle(previewView: androidx.camera.view.PreviewView, onReady: (Camera) -> Unit) {
        val providerFuture = ProcessCameraProvider.getInstance(context)
        providerFuture.addListener({
            cameraProvider = providerFuture.get()

            preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }

            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setJpegQuality(100)
                .build()

            val recorder = Recorder.Builder()
                .setQualitySelector(
                    QualitySelector.fromOrderedList(
                        listOf(Quality.UHD, Quality.FHD, Quality.HD),
                        FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                    )
                )
                .build()
            videoCapture = VideoCapture.withOutput(recorder)

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            // Attach Camera2 extension options for manual control before binding.
            val captureBuilder = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setJpegQuality(100)
            val ext = Camera2Interop.Extender(captureBuilder)
            manualIso?.let { ext.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, it) }
            manualExposureNs?.let { ext.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, it) }
            if (manualIso != null || manualExposureNs != null) {
                ext.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            }
            manualFocusDistance?.let {
                ext.setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, it)
                ext.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
            }
            // Enable optical/electronic video stabilization if available on this device.
            ext.setCaptureRequestOption(
                CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON
            )
            imageCapture = captureBuilder.build()

            cameraProvider?.unbindAll()
            camera = cameraProvider?.bindToLifecycle(
                lifecycleOwner, cameraSelector, preview, imageCapture, videoCapture
            )
            camera?.let(onReady)
        }, ContextCompat.getMainExecutor(context))
    }

    /** Standard single-shot max-quality capture. */
    fun capturePhoto(onSaved: (String) -> Unit, onError: (Exception) -> Unit) {
        val name = fileName("IMG")
        val values = photoContentValues(name)
        val outputOptions = ImageCapture.OutputFileOptions.Builder(
            context.contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ).build()

        imageCapture.takePicture(outputOptions, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                onSaved(name)
            }
            override fun onError(exception: ImageCaptureException) {
                onError(exception)
            }
        })
    }

    /**
     * Captures three exposures in quick succession (under-exposed, metered, over-exposed)
     * and merges them into a single high dynamic range JPEG using ImageProcessing.fuseExposures.
     */
    fun captureHdrBracket(
        onSaved: (String) -> Unit,
        onError: (Exception) -> Unit
    ) {
        val exposures = listOf(-2, 0, 2) // EV offsets
        val bitmaps = mutableListOf<android.graphics.Bitmap>()

        fun captureNext(index: Int) {
            if (index >= exposures.size) {
                val fused = ImageProcessing.fuseExposures(bitmaps)
                val sharpened = ImageProcessing.unsharpMask(fused)
                val name = fileName("HDR")
                ImageProcessing.saveBitmap(context, sharpened, name)
                onSaved(name)
                return
            }
            camera?.cameraControl?.setExposureCompensationIndex(exposures[index])
            imageCapture.takePicture(cameraExecutor, object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    bitmaps.add(ImageProcessing.imageProxyToBitmap(image))
                    image.close()
                    captureNext(index + 1)
                }
                override fun onError(exception: ImageCaptureException) {
                    onError(exception)
                }
            })
        }
        captureNext(0)
    }

    fun startVideoRecording(onSaved: (String) -> Unit) {
        val name = fileName("VID")
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        }
        val outputOptions = MediaStoreOutputOptions.Builder(
            context.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        activeRecording = videoCapture.output
            .prepareRecording(context, outputOptions)
            .withAudioEnabled()
            .start(ContextCompat.getMainExecutor(context)) { event ->
                if (event is VideoRecordEvent.Finalize && !event.hasError()) {
                    onSaved(name)
                }
            }
    }

    fun stopVideoRecording() {
        activeRecording?.stop()
        activeRecording = null
    }

    /** Reads sensor's minimum focus distance and ISO range, useful for building manual UI sliders. */
    fun getSensorCapabilities(): SensorCapabilities? {
        val cam = camera ?: return null
        val info = Camera2CameraInfo.from(cam.cameraInfo)
        val chars = info.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE)
        val isoRange = info.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        return SensorCapabilities(
            minFocusDistance = chars ?: 0f,
            isoMin = isoRange?.lower ?: 50,
            isoMax = isoRange?.upper ?: 3200
        )
    }

    private fun fileName(prefix: String): String {
        val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
        return "${prefix}_${sdf.format(System.currentTimeMillis())}"
    }

    private fun photoContentValues(name: String): ContentValues = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, name)
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.P) {
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ProCamera")
        }
    }
}

data class SensorCapabilities(
    val minFocusDistance: Float,
    val isoMin: Int,
    val isoMax: Int
)
