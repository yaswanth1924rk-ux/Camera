# ProCamera

A Kotlin + Jetpack Compose + CameraX camera app built to get the best possible photo and
video quality out of the Galaxy A36's hardware.

## Honest expectations

The A36 has smaller sensors, a simpler lens system, and a less powerful image signal
processor than an iPhone 17 / 17 Pro Max. No app can change the physics of the sensor or
add optical zoom lenses that aren't there. This app instead pushes every software lever
available on Android to close the gap as much as possible:

- **Max quality JPEG capture** — `CAPTURE_MODE_MAXIMIZE_QUALITY` + 100% JPEG quality,
  trading shot-to-shot speed for detail (this is the same trade-off iPhone's "Photographic
  Styles" / ProRAW pipeline makes).
- **HDR bracket mode** — captures 3 exposures (-2EV, 0EV, +2EV) and fuses them with an
  exposure-fusion algorithm (`ImageProcessing.fuseExposures`) so shadows and highlights
  both keep detail, similar to Smart HDR / Deep Fusion.
- **Unsharp mask pass** — recovers edge detail that the sensor's default noise reduction
  softens (`ImageProcessing.unsharpMask`).
- **Manual mode** — direct ISO and shutter speed control via `Camera2Interop`, for shots
  where auto-exposure picks the wrong trade-off (night shots, moving subjects).
- **Video** — requests the highest supported quality (UHD with fallback to FHD/HD) and
  turns on the sensor's video stabilization mode if the A36's camera HAL supports it.

## Project structure

```
app/src/main/java/com/procamera/app/
  MainActivity.kt       — permissions + Compose entry point
  CameraScreen.kt        — UI: preview, mode switcher, shutter, manual sliders
  CameraController.kt    — CameraX use case setup, capture/record logic
  ImageProcessing.kt     — HDR fusion + sharpening (pure Kotlin, no native deps)
```

## Building

1. Open the `ProCamera` folder in Android Studio (Koala or newer recommended).
2. Let Gradle sync — it will download CameraX, Compose, and AndroidX dependencies.
3. Connect your Galaxy A36 via USB with USB debugging enabled, and hit Run.
4. Grant camera + microphone permissions when prompted.

Minimum SDK is 26 (Android 8.0); the A36 ships with a much newer Android version so
you're well covered.

## Possible next steps

- Add RAW (DNG) capture via `ImageCapture` + `Camera2Interop` if the A36's camera reports
  `RAW_SENSOR` in `REQUEST_AVAILABLE_CAPABILITIES` (not all mid-range Samsung sensors expose
  this — worth checking with a capabilities probe first).
- Swap the hand-rolled exposure fusion for Google's CameraX `ExtensionsManager` HDR/Night
  vendor extension if Samsung ships one for this device — it'll be faster and use the ISP.
- Add a night mode that does a longer multi-frame burst + alignment for low light, similar
  to what this app's HDR mode does but weighted for brightness recovery instead of dynamic range.
